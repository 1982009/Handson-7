import { Controller, Delete, Get, Post, Put } from '@nestjs/common';
import { SongsService } from './songs.service';

@Controller('songs')
export class SongsController {
    constructor(private songService: SongsService){}
    @Post()
    create() {
        return "Create song"
    }

    @Get()
    findAll(){
        return "Get all songs"
    }

    @Get(':id') 
    findOne(){
        return "Get song by id"
    }

    @Put(':id')
    update(){
        return "Update song by id"
    }

    @Delete(':id')
    delete(){
        return "Delete song by id"
    }
}
    

