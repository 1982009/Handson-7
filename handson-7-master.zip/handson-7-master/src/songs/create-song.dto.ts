class CreateSongDTO {
    title: string;
    artist: string;
}