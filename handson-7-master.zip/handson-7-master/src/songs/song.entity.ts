export class Song {
    id : number;
    title : string;
    artist : string;
}